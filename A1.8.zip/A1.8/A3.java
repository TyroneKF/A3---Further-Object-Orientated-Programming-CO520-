
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JPanel.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;

class A3 extends JFrame{ 
    private final static JFrame window = new JFrame("Evade The Bomb");
    // left Panel setup variables
    private final static int gap = 2;
    private final static int rows = 2;
    private final static int columns = 5;
    private final static int totalPanels = rows * columns;

    private static JPanel  leftPanel = new JPanel(new GridLayout(rows, columns,gap,gap));
    private static JPanel [] panel = new JPanel[totalPanels];

    private static Handlerclass handler = new Handlerclass();

    // Game Variables
    private static  boolean playing = false;
    private static int points = 0;
    private static boolean diffcultySelected = false;
    private static int noOfAttempts = -1;
    private static int bombedField = 0;

    private static Random random = new Random();
    private static int minVal = 0;
    private static int maxVal = 9;

    private static ArrayList<Boolean> chosenPanels = new ArrayList<Boolean>();

    // Screen Objects
    private static JLabel pointsLabel;

    public static void main(String[] args)
    {   
        makeFrame(); 
        Boolean[] startValues = new Boolean[]{false,false,false,false,false,false,false,false, false,false};
        Collections.addAll(chosenPanels, startValues);
    } 

    private static void makeFrame()
    {   //####################################################################
        // Main Window / Panels 
        //####################################################################

        // Creating Window

        window.setVisible(true);
        window.setSize(850,500);
        window.setResizable(false);
        window.setLocation(100,200);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Creating Container
        Container contentPane= window.getContentPane();
        contentPane.setLayout(new GridLayout());
        contentPane.setVisible(true);       

        //####################################################################
        //  Panel Initilization
        //####################################################################

        leftPanel.setBackground(Color.RED);
        contentPane.add(leftPanel);

        // Creating middle Panel
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.BLUE);
        contentPane.add(middlePanel);

        // Creating Right Panel
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.GREEN); 
        contentPane.add(rightPanel,new FlowLayout());

        //####################################################################
        // Label Initilization playGame
        //####################################################################
        Font labelFont = new Font("Arial", Font.BOLD,10);

        pointsLabel = new JLabel("");
        pointsLabel.setBounds(20,150, 150,150);
        pointsLabel.setForeground(Color.white);
        pointsLabel.setFont(labelFont);
        //####################################################################
        // Mouse Initilization playGame
        //####################################################################

        //####################################################################
        // Button Initilization playGame
        //####################################################################

        // Middle Panel
        JButton playGameBut = new JButton("Play Game");
        playGameBut.setBounds(85,20, 100,25);

        JButton exitGameBut = new JButton("Exit");
        exitGameBut.setBounds(85,60, 100,25);

        // Right Panel
        JButton easyModeBut = new JButton("Easy");
        easyModeBut.setBounds(85,20, 100,25);

        JButton intermediateModeBut = new JButton("Intermediate");
        intermediateModeBut.setBounds(85,60, 100,25);

        JButton difficultModeBut = new JButton("Difficult");
        difficultModeBut.setBounds(85,100, 100,25);

        //####################################################################
        //  Creating Button Lambda's
        //####################################################################

        // Middle Panel Button  Event Programming
        playGameBut.addActionListener(ae -> 
            { 
                if(!playing && !diffcultySelected)
                {
                    JOptionPane.showMessageDialog(window, "Select A difficulty on the last panel.\n To play please!");
                }

                else
                {                     
                    startGameConditions();
                    System.out.println("\n\nMoves to begin with: " + noOfAttempts);
                }
            });

        exitGameBut.addActionListener(ae -> 
            { 
                window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));                    
            });

        //####################################################################
        // Right Panel Button  Event Programming

        easyModeBut.addActionListener(ae -> 
            {   
                if(!playing)
                {
                    noOfAttempts = 5;
                    modeSelectionMsg(noOfAttempts, "Easy");
                    diffcultySelected = true;

                }                 
                else
                {
                    inGameMessage(); 
                }
            });

        intermediateModeBut.addActionListener(ae -> 
            { 
                if(!playing)
                {
                    noOfAttempts = 7;
                    modeSelectionMsg(noOfAttempts, "Intermediate");
                    diffcultySelected = true;
                }                 
                else
                {
                    inGameMessage(); 
                }
            });

        difficultModeBut.addActionListener(ae -> 
            { 
                if(!playing)
                {
                    noOfAttempts = 9;
                    modeSelectionMsg(noOfAttempts, "Difficult");
                    diffcultySelected = true;
                }                 
                else
                {
                    inGameMessage(); 
                }
            });

        //####################################################################
        //  Adding Objects TO Panel & The Screen
        //####################################################################
        middlePanel.add(playGameBut);
        middlePanel.add(exitGameBut);
        middlePanel.add(pointsLabel);

        rightPanel.add(easyModeBut);
        rightPanel.add(intermediateModeBut);
        rightPanel.add(difficultModeBut);      

        createRightFrame();       

    }

    private static void startGameMsg()
    {
        JOptionPane.showMessageDialog(window, "Select a difficulty and press 'Play Game' to Start / Reset the game.");
    }

    private static void modeSelectionMsg(int x, String mode)
    {
        JOptionPane.showMessageDialog(window, "You have chosen " + mode + "\nYou have to clear " + noOfAttempts + " panels to win!\nNow press 'Play Game' to start the Game");
    }

    private static void inGameMessage()
    {
        JOptionPane.showMessageDialog(window, " You are in a current Game!");
    }

    private static void settingBombedFields()
    {        
        bombedField = random.nextInt(maxVal + 1 - minVal) + minVal;
        //System.out.println("Bombed Square =" + bombedField);
    }

    private static Boolean hasPanelNotBeenClicked(int x)
    {   
        if(chosenPanels.get(x) == false){
            return true;
        }
        else{
            return false;
        }
    }

    private static void checkingMove(int x)
    {           
        if(playing && diffcultySelected)
        {   
            if(noOfAttempts>=0)
            {   if(hasPanelNotBeenClicked(x))
                {   
                    chosenPanels.set(x,true);                    

                    if(x == bombedField)
                    {
                        panel[x].setBackground(Color.BLACK);
                        pointsLabel.setText("You Lose! \nYou got " + points + " points");
                        System.out.println("\nGame Over! You Hit the BOMB\nYou Scored " + points + " points!");
                        endGameConditions();
                    }
                    else
                    {
                        changePanelColour(x);
                        points+=1;
                        noOfAttempts -= 1;

                        if(noOfAttempts<= 0)
                        {
                            System.out.println("\nYou Won, Congratualations \n You Scored " + points + " points!");
                            pointsLabel.setText("You Won!" + "\nYou Scored " + points + " points!");
                            endGameConditions();
                        }
                    }
                    if(noOfAttempts > 0)
                    {
                        System.out.println("Moves left at end: " + noOfAttempts);
                    }
                }
                else
                {
                    System.out.println("Panel has already been clicked!");
                }

            }
        }

        else
        {
            startGameMsg();
        }
    }

    private static void startGameConditions()
    {
        playing = true;
        points = 0;
        pointsLabel.setText("");
        settingBombedFields();
        resetColourOfAllPanels();
        
        chosenPanels.clear();
        Boolean[] startValues = new Boolean[]{false,false,false,false,false,false,false,false, false,false};
        Collections.addAll(chosenPanels, startValues);
    }

    private static void endGameConditions()
    {
        playing = false;
        points = 0;        
        noOfAttempts = -1;
        bombedField = 0;
        diffcultySelected = false;
    }

    private static void changePanelColour(int x)
    {
        panel[x].setBackground(Color.YELLOW);

    }

    private static void resetColourOfAllPanels()
    {
        for (int i = 0; i< totalPanels; i ++)
        {
            panel[i].setBackground(Color.RED);
        }
    }

    private static void createRightFrame()
    {   
        for (int i = 0; i< totalPanels; i ++)
        { 
            panel[i] = new JPanel();
            panel[i].setBorder(BorderFactory.createLineBorder(Color.WHITE));
            panel[i].setBackground(Color.RED);
            // Adding Event Listeners to the panel
            panel[i].addMouseListener(handler);
            panel[i].setName(String.valueOf(i));
            leftPanel.add(panel[i]);          

        }
    }

    private static class Handlerclass implements MouseListener 
    {
        public void mouseClicked(MouseEvent event)
        {

        }

        public void mousePressed(MouseEvent event)
        {
            Component panelx = (Component) event.getSource();
            checkingMove(Integer.valueOf(panelx.getName()));            
        }

        public void mouseReleased(MouseEvent event)
        {

        }

        public void mouseEntered(MouseEvent event)
        {

        }

        public void mouseExited(MouseEvent event)
        {

        }
    }

}